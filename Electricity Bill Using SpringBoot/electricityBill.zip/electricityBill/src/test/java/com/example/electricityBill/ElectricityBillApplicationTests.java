package com.example.electricityBill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricityBillApplicationTests {

	@Test
	void contextLoads() {
	}

}
